#!/usr/bin/python3
# EJUDGE_FLAGS=dump 0x10010000-0x10210000 HexText /dev/stdout
import sys

WIDTH, HEIGHT = 256, 128


def worth(idx, arr):
    return all(arr[idx + dx + dy] == arr[idx]
               for dx in (-1, 0, 1)
               for dy in (-WIDTH, 0, WIDTH) if 0 <= idx + dx + dy < len(arr))


with open(sys.argv[2]) as f:
    Data = [int(line, 16) for line in f]

with open(sys.argv[3]) as f:
    Answer = [int(line, 16) for line in f]

WIDTH, HEIGHT = 1, len(Answer)
while WIDTH < HEIGHT:
    WIDTH *= 2
    HEIGHT //= 2

# print(WIDTH, HEIGHT)

if len(Data) != len(Answer):
    sys.exit(4)

if any(worth(i, Answer) and Answer[i] != Data[i] for i in range(len(Data))):
    sys.exit(5)
