#!/usr/bin/env python3
'''
Convert RARS dump 0x10010000-0x10210000 HexText to image
'''
# limit: 1024
# argv: ../o

import sys
import os
import numpy as np
from PIL import Image
WIDTH, HEIGHT = 1024, 1024


def BGR(rgb):
    return (rgb & 0xff) << 16 | (rgb & 0xff00) | (rgb & 0xff0000) >> 16


with open(sys.argv[1]) as f:
    Data = [BGR(int(line, 16)) for line in f.readlines()]
while len(Data) < WIDTH * HEIGHT:
    if HEIGHT >= WIDTH:
        HEIGHT //= 2
    else:
        WIDTH //= 2
if len(Data) != WIDTH * HEIGHT:
    raise os.error(f"Invalid pixmap size {len(Data)}")
im = Image.new('RGB', (WIDTH, HEIGHT))
im.putdata(Data)
im.save(sys.argv[1] + ".png")
